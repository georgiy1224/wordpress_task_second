=== Plugin Name ===
Contributors: mariokostelac
Donate link: http://mariokostelac.com/
Tags: comingsoon, easy, simple, under-construction, coming-soon
Requires at least: 2.9.2
Tested up to: 3.0.1
Stable tag: 1.0.1

Simple plugin provides easy setuping coming soon page.

== Description ==

Simple plugin provides easy setuping coming soon page by clicking on dropdown menu.

It offers you two site states:
* Usual, running site
* Coming soon page

Independent of selected state, logged administrators always see the full, running site.
This is very useful for site maintance and fixing.

At the moment, there is one predefined theme, but you can create the custom one
by creating coming-soon.php file into your active theme folder.

If you have any question(s) related to this plugin, ask me on http://mariokostelac.com and feel
free to drop me a line on mario.kostelac[at]gmail.com


== Installation ==

1. Download plugin from admin or Upload the directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it, there is no third step

== Frequently Asked Questions ==

There is no questions for now.
If there will be, you'll be able to see them (and answers) on http://mariokostelac.com

== Screenshots ==

1. Configuration page 1
2. Configuration page 2
3. Built-in theme
4. You can create coming soon pages like this by creating coming-soon.php in your active theme directory (screenshot from http://www.zoranaprljic.com/)

== Changelog ==

= 1.0.1 =
* fixed bug with including custom coming-soon.php
* added support for gecko based browsers (rounded-borders)

= 1.0 =
* initial release
