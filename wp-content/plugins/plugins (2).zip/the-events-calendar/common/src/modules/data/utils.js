export const PREFIX_COMMON_STORE = '@@MT/COMMON';
