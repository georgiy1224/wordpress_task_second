<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Changelog_Reader.php' );

class Tribe__Events__Changelog_Reader extends Tribe__Changelog_Reader {}
