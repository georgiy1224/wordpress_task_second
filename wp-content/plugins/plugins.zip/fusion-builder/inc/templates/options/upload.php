<div class="fusion-upload-image">
	<input type="hidden" id="{{ param.param_name }}" name="{{ param.param_name }}" class="regular-text fusion-builder-upload-field" value='{{ option_value }}' />
	<div class="preview"></div>
	<input type='button' class='button-upload fusion-builder-upload-button' value='{{ fusionBuilderText.upload_image }}' data-type="image" data-param="{{ param.param_name }}" data-title="{{ fusionBuilderText.select_image }}" />
</div>
